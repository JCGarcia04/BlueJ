
/**
 * Write a description of class CarInsurancePolicy here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CarInsurancePolicy
{
    public static void main()
    {
        CarInsurancePolicy(987654, 2, "Angeles");
        CarInsurancePolicy(987654,2);
        CarInsurancePolicy(987654, 2500, 1200, "Angeles");
    }
    
    static void CarInsurancePolicy(int polNum, int numOfPay, String city)
    {
        System.out.println("Policy Number: " + polNum+ " Number of Payment: " + numOfPay+ " Resident City: " + city);
    }
    
    static void CarInsurancePolicy(int polNum, int numOfPay)
    {
        System.out.println("Policy Number: " + polNum + " Number of Payment: " + numOfPay);
    }
    
    static void CarInsurancePolicy(int polNum, int ann1, int ann2, String city)
    {
        int tAnn;
        tAnn = ann1 + ann2;
        System.out.println("Policy Number: " + polNum+ " Total Annual Payments: " + tAnn+ " Resident City: " + city);
    }
    
}
