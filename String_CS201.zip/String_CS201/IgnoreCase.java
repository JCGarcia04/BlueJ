
/**
 * Write a description of class IgnoreCase here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IgnoreCase
{
    public static void main(String[] args)
    {
        String Name1 = "john";
        String Name2 = "JOHNNY";
        
        System.out.println(Name1.equalsIgnoreCase(Name2));
        System.out.println(Name1.toUpperCase());
        System.out.println(Name2.toLowerCase());
        if(Name1.length() == Name2.length())
        {
            int tlength = Name1.length() + Name2.length();
            System.out.println(Name1 + " length is " + Name1.length() + " is equal to " + Name2 + " length is " + Name2.length() + " total length is equivalent to > " + tlength);
        }
        else
        {
            System.out.println(Name1 + " length is " + Name1.length() + " is not equal to " + Name2 + " length is " + Name2.length());
        }
    }
}
