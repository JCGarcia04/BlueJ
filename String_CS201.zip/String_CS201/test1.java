
/**
 * Write a description of class test here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class test1 extends JFrame 
{
    JFrame frame = new JFrame();
    
    JButton okButton = new JButton();
    JButton exitButton = new JButton();
    
    JLabel fNameLabel = new JLabel();
    JLabel lNameLabel = new JLabel();
    JLabel sectionLabel = new JLabel();
    
    JTextField fNameTextField = new JTextField();
    JTextField lNameTextField = new JTextField();
    JTextField sectionTextField = new JTextField();
 
    public test1()
    {
        setTitle("Enter Information");
        
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints ();
             
        fNameLabel.setText("Enter First Name");
        gridConstraints.gridx=0;
        gridConstraints.gridy=0;
        getContentPane().add(fNameLabel,gridConstraints);
        
        lNameLabel.setText("Enter Last Name");
        gridConstraints.gridx=0;
        gridConstraints.gridy=2;
        getContentPane().add(lNameLabel,gridConstraints);
        
        sectionLabel.setText("Enter Section");
        gridConstraints.gridx=0;
        gridConstraints.gridy=4;
        getContentPane().add(sectionLabel,gridConstraints);
        
        fNameTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=0;
        getContentPane().add(fNameTextField,gridConstraints);
        
        lNameTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=2;
        getContentPane().add(lNameTextField,gridConstraints);
        
        sectionTextField.setColumns(15);
        gridConstraints.gridx=2;
        gridConstraints.gridy=4;
        getContentPane().add(sectionTextField,gridConstraints);
        
        okButton.setText("OK");
        gridConstraints.gridx=0;
        gridConstraints.gridy=6;
        getContentPane().add(okButton,gridConstraints);
        
        okButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                okButtonActionPerformed(e);
            }
        });     
               
        exitButton.setText("Exit");
        gridConstraints.gridx=2;
        gridConstraints.gridy=6;
        getContentPane().add(exitButton,gridConstraints);
        
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformed(e);
                System.exit(0);
            }
        });
        
        pack();
    }
    
    private void okButtonActionPerformed(ActionEvent e)
    {
        String s1 = fNameTextField.getText();
        String s2 = lNameTextField.getText();
        String s3 = sectionTextField.getText();
        JOptionPane.showMessageDialog(null, "Good Morning! " + s1 + " "+ s2 + " and \n Welcome to! " + s3);
    }
    
    private void exitButtonActionPerformed(ActionEvent e)
    {
        JOptionPane.showMessageDialog(null, "Thanks!");
    }
    
    
    public static void main(String[] args)
    {
        new test1().show();
    }
}