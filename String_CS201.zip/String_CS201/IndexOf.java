
/**
 * Write a description of class IndexOf here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IndexOf
{
    public static void main(String[] args)
    {
        String a = "Holy Angel University";
        
        System.out.println(a.indexOf("Holy",5));
        
    }
}
