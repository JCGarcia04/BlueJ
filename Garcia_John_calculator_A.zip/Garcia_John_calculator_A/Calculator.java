import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Calculator extends JFrame
{
    JFrame frame = new JFrame();
    
    JLabel t_var1 = new JLabel();
    JLabel t_op = new JLabel();
    JLabel t_var2 = new JLabel();
    JLabel result = new JLabel();
        
    JTextField var1 = new JTextField();
    JTextField operator = new JTextField();
    JTextField var2 = new JTextField();
    JTextField ans = new JTextField();
        
    JButton calc = new JButton();
    JButton exit = new JButton();
    
    double a;
    double b;
    double temp;
    
    public Calculator()
    {
        setTitle("Simple Calculator");
        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        t_var1.setText("Operand 1:");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(t_var1,gridConstraints);
        
        var1.setText("                 ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 1;
        getContentPane().add(var1,gridConstraints);
        
        t_op.setText("Operator:");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        getContentPane().add(t_op,gridConstraints);
        
        operator.setText("                 ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 3;
        getContentPane().add(operator,gridConstraints);
        
        t_var2.setText("Operand 2:");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 5;
        getContentPane().add(t_var2,gridConstraints);
        
        var2.setText("                 ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 5;
        getContentPane().add(var2,gridConstraints);
        
        result.setText("Result:");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 7;
        getContentPane().add(result,gridConstraints);
        
        ans.setText("                 ");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 7;
        getContentPane().add(ans,gridConstraints);
        ans.setEditable(false);
        
        calc.setText("Calculate");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 9;
        getContentPane().add(calc,gridConstraints);
        
        exit.setText("Exit");
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 9;
        getContentPane().add(exit,gridConstraints);

        pack();
        
        setSize(500,500);
    }
        
    public void calcActionPerformed(ActionEvent e) {
        a = Double.parseDouble(String.valueOf(var1));
        b = Double.parseDouble(String.valueOf(var2));
        switch(String.valueOf(operator)){
        case "+":
            temp = a + b;
            break;
        case "-":
            temp = a - b;
            break;
        case "*":
            temp = a * b;
            break;
        case "/":
            temp = a / b;
            break;
        }
    }
    
    public static void main(String[] args)
    {
        new Calculator().show();
    }
}






