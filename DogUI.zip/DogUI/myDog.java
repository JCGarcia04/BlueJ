public class myDog extends Dog
{
    public static void main(String[] args)
    {
        Dog.Info();
    }
}
