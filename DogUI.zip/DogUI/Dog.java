public class Dog
{
    static String name = "Tofu";
    static String breed = "Samoyed";
    static int tag_number = 2;
    
    public static void main(String[] args)
    {
       Info();
    }
    
    public static void Info()
    {
        System.out.println(name);
        System.out.println(breed);
        System.out.println(tag_number);
    }
}
