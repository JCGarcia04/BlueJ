import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Dog_UI
{
    JFrame frame;
    JTextField[] inputs = new JTextField[3];
    JTextField name_t, breed_t, tag_number_t;
    JButton[] optButtons = new JButton[2];
    JButton enterButton, exitButton;
    JLabel[] inputname = new JLabel[3];
    JLabel name_l, breed_l, tag_number_l;
    
    String name, breed;
    int tag_number;
        
    Dog_UI()
    {
        frame = new JFrame("Dog Information");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350,200);
        frame.setLayout(null);
        
        //label
        name_l = new JLabel("Enter Dog's Name: ");
        name_l.setBounds(30, 20, 1500, 20);
        breed_l = new JLabel("Enter Dog's Breed: ");
        breed_l.setBounds(30, 50, 150, 20);
        tag_number_l = new JLabel("Enter Dog's Tag Number: ");
        tag_number_l.setBounds(30, 80, 150, 20);
        
        //textfield
        name_t = new JTextField("");
        name_t.setBounds(150, 20, 100, 20);
        breed_t = new JTextField("");
        breed_t.setBounds(150, 50, 100, 20);
        tag_number_t = new JTextField("");
        tag_number_t.setBounds(185, 80, 100, 20);
        
        //button
        enterButton = new JButton("Enter");
        enterButton.setBounds(90, 120, 75, 20);
        exitButton = new JButton("Exit");
        exitButton.setBounds(175, 120, 75, 20);
        
        
        frame.add(name_l);
        frame.add(breed_l);
        frame.add(tag_number_l);
        frame.add(name_t);
        frame.add(breed_t);
        frame.add(tag_number_t);
        frame.add(enterButton);
        frame.add(exitButton);

        frame.setVisible(true);
        
        /*enterButton.addActionListener(new ActionListener (){
            public void actionPerformed(ActionEvent e){
                enterButtonActionPerformed(e);
            }
        });*/
        
        exitButton.addActionListener(new ActionListener (){
            public void actionPerformed(ActionEvent e){
                exitButtonActionPerformed(e);
            }
        });
    }
    public static void main(String[] args)
    {
        Dog_UI dogui = new Dog_UI();
    }
    
    public void enterButtonActionPerformed(ActionEvent e)
    {
        
    }
    
    public void exitButtonActionPerformed(ActionEvent e)
    {
        System.exit(0);
    }
}
