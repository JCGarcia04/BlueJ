import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.Color;

public class main extends CarLoanAssessment
{
    public static void main(String args[]) { 
        functionHome t=new functionHome(); 
        t.homePage();
    }
}

class CarLoanAssessment{
    //to get the datas
    //global variable for frame 1
    JTextField firstText, middleText, lastText, tAge;
    JComboBox comboCivil;
    
    //global variable for frame 2
    JComboBox comboType, comboVehicleBrand, comboDown, comboTerm;
    JTextField tPrice, tVehicleModel;
    //global variable for frame 3
    JTextField tStreet, tBarangay, tProvince, tPhone, tMobile, tEmail;
    JComboBox comboStay, comboResidence;

    //global variable for frame 4
    JComboBox comboIncome, comboTenure;
    JTextField tCompanyName, tCompanyAdd, tTele, tPosition, tMonthlyIncome;
    JFrame f = new JFrame("KK&JC Incorporated");
    public void homePage(){
        JFrame fHome = new JFrame("KK&JC Incorporated");
        fHome.setLayout(null);
        fHome.setVisible(true);
        fHome.setSize(350,430);
        functionHome t=new functionHome(); 
        //call the method
    
        //menuuuuuuuuuu
               
        //label
        JLabel ComapanyName, belowCompany;
        
        ComapanyName = new JLabel("K K & J C");
        ComapanyName.setBounds(60,30,250,50);
        ComapanyName.setFont(new Font("Serif", Font.PLAIN, 50));
        fHome.add(ComapanyName);
        
        belowCompany = new JLabel("Car Loan Assessment");
        belowCompany.setBounds(80,80,190,30);
        belowCompany.setFont(new Font("Serif", Font.PLAIN, 20));
        fHome.add(belowCompany);
        
        //button
        JButton bLoanCalcu, bApplyLoan, bAutoLoan, bAboutUS, bExit;
        bLoanCalcu = new JButton("Loan Calculator");
        bLoanCalcu.setBounds(50,160,230,30);
        bLoanCalcu.setFont(new Font("Sans Serif", Font.PLAIN, 16));
        fHome.add(bLoanCalcu);
        
        bApplyLoan = new JButton("Apply Loan");
        bApplyLoan.setBounds(50,200,230,30);
        bApplyLoan.setFont(new Font("Sans Serif", Font.PLAIN, 16));
        fHome.add(bApplyLoan);
        
        bAutoLoan = new JButton("Auto Loan Self-Assessment");
        bAutoLoan.setBounds(50,240,230,30);
        bAutoLoan.setFont(new Font("Sans Serif", Font.PLAIN, 16));
        fHome.add(bAutoLoan);
        
        bAboutUS = new JButton("About Us");
        bAboutUS.setBounds(50,280,230,30);
        bAboutUS.setFont(new Font("Sans Serif", Font.PLAIN, 16));
        fHome.add(bAboutUS);
        
        bExit = new JButton("Exit");
        bExit.setBounds(50,320,230,30);
        bExit.setFont(new Font("Sans Serif", Font.PLAIN, 16));
        fHome.add(bExit);
    
        bLoanCalcu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                t.calculatorFrame();
                fHome.setVisible(false);
            }
        });
        bApplyLoan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                applyClass newApply = new applyClass();
                newApply.applyFrame();
                fHome.setVisible(false);
            }
        });
        bAutoLoan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                loanAssessment newLoanAssess = new loanAssessment();
                newLoanAssess.autoLoanAssessment();
                fHome.setVisible(false);
            }
        });
        bAboutUS.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                
                about newAbout = new about();
                newAbout.aboutUsFrame();
                fHome.setVisible(false);
            }
        });
        bExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                System.exit(0);
            }
        });
    }

}
class functionHome extends CarLoanAssessment{
    //Frame for calculator
        public void calculatorFrame(){
        
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(420,290);
        
        //menu bar
        JMenu menu;
        JMenuItem home; 
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("≡");
        home=new JMenuItem("back to Home"); 
        menu.setFont(new Font("Serif", Font.BOLD, 20));
        
        menuBar.add(menu); 
        f.setJMenuBar(menuBar);
        
        menu.add(home);
        //menu bar action
        home.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                homePage();
                f.setVisible(false);
            }
        });
        
        JLabel lTitle,lPrice, lDown, lterm;
        lTitle = new JLabel("Loan Calculator");
        lTitle.setBounds(20,10,300,30);
        f.add(lTitle);
            
        lPrice = new JLabel("Purchase Price: (No Comma)");
        lPrice.setBounds(20,50,180,30);
        f.add(lPrice);
            
        lDown = new JLabel("Downpayment %:");
        lDown.setBounds(20,90,150,30);
        f.add(lDown);
            
        lterm = new JLabel("Payment Terms");
        lterm.setBounds(20,130,150,30);
        f.add(lterm);
       
        //textfield
        tPrice = new JTextField();
        tPrice.setBounds(200,55,180,25);
        f.add(tPrice);
        JLabel label = new JLabel();

        tPrice.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
    
            //combo box
        String[] listdown = {"Please Select","15","20","30", "40", "50", "60","70"};
        String[] listterm = {"Please Select", "12","18","24", "36", "48", "60"};
        
        comboDown = new JComboBox(listdown);
        comboDown.setBounds(200,95,180,25);
        f.add(comboDown);
        
        comboTerm = new JComboBox(listterm);
        comboTerm.setBounds(200,135,180,25);
        f.add(comboTerm);
        
        //button
        JButton calculate = new JButton("Calculate");
        calculate.setBounds(140,180,90,30); 
        f.add(calculate);
        calculate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if (comboDown.getSelectedItem().equals("Please Select") || comboTerm.getSelectedItem().equals("Please Select") || tPrice.getText().equals("")){
                    JOptionPane.showMessageDialog(f,"Fill up the empty text field");
                }
                if (comboDown.getSelectedItem().equals("Please Select")){
                    comboDown.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (comboTerm.getSelectedItem().equals("Please Select")){
                    comboTerm.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (tPrice.getText().equals("")){
                    tPrice.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }

                
                else{
                    comboDown.setBorder(BorderFactory.createLineBorder(Color.white));
                    comboTerm.setBorder(BorderFactory.createLineBorder(Color.white));
                    tPrice.setBorder(BorderFactory.createLineBorder(Color.white));
                    double Downpayment = Double.parseDouble((String)comboDown.getSelectedItem());
                    double term = Double.parseDouble((String)comboTerm.getSelectedItem());
                    double price = Double.parseDouble((String)tPrice.getText());
                    double totalDown = price * (Downpayment/100);
                    double loanAmount = price - totalDown;
                    double monthly = price / term;
                    //display everymonthy paybills with interest
                    double Everymonth_Interest = monthly + (loanAmount * (1.7/100));
                    //display total amount with interest
                    double Amount_Interest = Everymonth_Interest * term;
                    JOptionPane.showMessageDialog(f, "\nDownpayment: P"+String.format("%.02f", totalDown)+"\nAmount Financed: P"+ String.format("%.02f", loanAmount)+ "\nMonthly Amortization: P"+ String.format("%.02f", Everymonth_Interest)+"\nTotal Amount(interest): "+ String.format("%.02f",Amount_Interest), "Loan Calculator", JOptionPane.INFORMATION_MESSAGE);
                  
                }
            
            }
        });
    }
}
class applyClass extends CarLoanAssessment{  
//frame for Apply loan
    public void applyFrame() {
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(925,810);
        JLabel lTitlef;
        lTitlef = new JLabel("Auto Loan Application Form");
        lTitlef.setBounds(20,2,300,30);
        f.add(lTitlef);
        
        //menu bar
        JMenu menu;
        JMenuItem home; 
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("≡");
        home=new JMenuItem("back to Home"); 
        menu.setFont(new Font("Serif", Font.BOLD, 20));
        
        menuBar.add(menu); 
        f.setJMenuBar(menuBar);
        
        menu.add(home);
        //menu bar action
        home.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                homePage();
                f.setVisible(false);
            }
        });
        
        //panel
        JPanel panel=new JPanel();
        panel.setLayout(null);
        panel.setBounds(10,30,440,260);
        panel.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        f.add(panel);
    
        
        
        JButton submit;
        submit = new JButton("Submit");
        submit.setBounds(405,705,100,30);
        f.add(submit);
        
        //Jlabel
        JLabel lTitle, lfirstName, lmiddleName, lLastName, lAge ,  lCivil;
            
        lTitle = new JLabel("Borrower's Personal Information");
        lTitle.setBounds(20,10,300,30);
        panel.add(lTitle);
            
        lfirstName = new JLabel("First Name");
        lfirstName.setBounds(20,50,80,30);
        panel.add(lfirstName);
            
        lmiddleName = new JLabel("Middle Name");
        lmiddleName.setBounds(20,90,80,30);
        panel.add(lmiddleName);
            
        lLastName = new JLabel("Last Name");
        lLastName.setBounds(20,130,80,30);
        panel.add(lLastName);
        
        lAge = new JLabel("Age");
        lAge.setBounds(20,170,80,30);
        panel.add(lAge);
    
        lCivil = new JLabel("Civil Status");
        lCivil.setBounds(20,210,80,30);
        panel.add(lCivil);
            
        //JtextField
        firstText = new JTextField();
        firstText.setBounds(210,55,210,25);
        panel.add(firstText);
    
        middleText = new JTextField();
        middleText.setBounds(210,95,210,25);
        panel.add(middleText);
            
        lastText = new JTextField();
        lastText.setBounds(210,135,210,25);
        panel.add(lastText);
        
        tAge = new JTextField();
        tAge.setBounds(210,175,210,25);
        tAge.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
        panel.add(tAge);
            
        //combobox
        String[] arrCivil = {"Please Select", "Single", "Annulled", "Widow", "Married", "Seperated"};
        comboCivil = new JComboBox(arrCivil);
        comboCivil.setBounds(210,215,210,25);
        panel.add(comboCivil);
    
        //panel 2
        JPanel panel2 = new JPanel();
        panel2.setLayout(null);
        panel2.setBounds(460,30,440,300);
        panel2.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        f.add(panel2);
        //label
        JLabel lTitle1, lType, lvehicleName, lVehicleModel ,lPrice, lDown, lTerm;
        lTitle1 = new JLabel("Vehicle Information");
        lTitle1.setBounds(20,10,200,30);
        panel2.add(lTitle1);    
        
        lType = new JLabel("Car Usage");
        lType.setBounds(20,50,80,30);
        panel2.add(lType);
        
        lvehicleName = new JLabel("Vehicle Brand");
        lvehicleName.setBounds(20,90,80,30);
        panel2.add(lvehicleName);
        
        
        lVehicleModel = new JLabel("Vehicle Model");
        lVehicleModel.setBounds(20,130,150,30);
        panel2.add(lVehicleModel);

        lPrice = new JLabel("Vehicle Price (No comma)");
        lPrice.setBounds(20,170,150,30);
        panel2.add(lPrice);
        
        lDown = new JLabel("Downpayment %");
        lDown.setBounds(20,210,100,30);
        panel2.add(lDown);
        
        lTerm = new JLabel("Term (Months)");
        lTerm.setBounds(20,250,100,30);
        panel2.add(lTerm);
        //laman ng combo boxes
        String[] type = {"Please Select","Brand New", "Second Hand"};
        String[] vehicleBrand = {"Please Select","Toyota","Mitsubishi", "Nissan", "Ford", "Suzuki"};
        String[] down = {"Please Select","15","20","30", "40", "50", "60","70"};
        String[] term = {"Please Select", "12","18","24", "36", "48", "60"};
        //Combo Boxes
        
        comboType = new JComboBox(type);
        comboType.setBounds(210,55,210,25);
        panel2.add(comboType);
        
        comboVehicleBrand = new JComboBox(vehicleBrand);
        comboVehicleBrand.setBounds(210,95,210,23);
        panel2.add(comboVehicleBrand);
        
        comboDown = new JComboBox(down);
        comboDown.setBounds(210,215,210,25);
        panel2.add(comboDown);
        
        comboTerm = new JComboBox(term);    
        comboTerm.setBounds(210,255,210,25);
        panel2.add(comboTerm);
        
        //Jtextfield ng price ng sasakyan
        tVehicleModel = new JTextField();
        tVehicleModel.setBounds(210,135,210,25);
        panel2.add(tVehicleModel);
        
        tPrice = new JTextField();
        tPrice.setBounds(210,175,210,25);
        panel2.add(tPrice);
    

        tPrice.addKeyListener(new KeyAdapter() {
        public void keyTyped(KeyEvent e) {
            char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
             }
        });
        
        //panel 3
        JPanel panel3 = new JPanel();
        panel3.setLayout(null);
        panel3.setBounds(10,300,440,390);
        panel3.setBorder(BorderFactory.createLineBorder(Color.black, 1));   
        f.add(panel3);
        //LAbels
        JLabel lTitle3, lHomeAdd, lStreet, lBarangay, lProvince, lStay, lResidence, lPhone, lMobile, lEmail;
        
        
        lHomeAdd = new JLabel("Home Details");
        lHomeAdd.setBounds(20,15,150,30);
        panel3.add(lHomeAdd);
        
        lStreet = new JLabel("Number / Street / Subdivision");
        lStreet.setBounds(20,60,200,30);
        panel3.add(lStreet);
        
        lBarangay = new JLabel("Barangay / Municipality");
        lBarangay.setBounds(20,100,200,30);
        panel3.add(lBarangay);
        
        lProvince = new JLabel("City / Province");
        lProvince.setBounds(20,140,150,30);
        panel3.add(lProvince);
        
        lStay = new JLabel("Length of Stay");
        lStay.setBounds(20,180,150,30);
        panel3.add(lStay);
        
        lResidence = new JLabel("Type of Residence");
        lResidence.setBounds(20,220,150,30);
        panel3.add(lResidence);
        
        lPhone = new JLabel("Home Phone");
        lPhone.setBounds(20,260,150,30);
        panel3.add(lPhone);
        
        lMobile = new JLabel("Mobile No.");
        lMobile.setBounds(20,300,150,30);
        panel3.add(lMobile);

        lEmail = new JLabel("Email Address");
        lEmail.setBounds(20,340,150,30);
        panel3.add(lEmail);
        
        //textField
        tStreet = new JTextField();
        tStreet.setBounds(210,65,210,25);
        panel3.add(tStreet);
        
        tBarangay = new JTextField();
        tBarangay.setBounds(210,105,210,25);
        panel3.add(tBarangay);
        
        tProvince = new JTextField();
        tProvince.setBounds(210,145,210,25);
        panel3.add(tProvince);
        
        //combo box
        String[] arrStay = {"Please Select", "Less than a year","1 to 2 years", "2 to 5 years", "5 years or more"};
        String[] arrResidence = {"Please Select", "Used free or Living with Parents/Relatives", "Owned(Fully Paid)", "Renting", "Owned(Amortizing a Housing Loan)"};
    
        comboStay = new JComboBox(arrStay);
        comboStay.setBounds(210,185,210,25);
        panel3.add(comboStay);
        
        comboResidence = new JComboBox(arrResidence);
        comboResidence.setBounds(210,225,210,25);
        panel3.add(comboResidence);
        
        //text field ulit
        tPhone = new JTextField();
        tPhone.setBounds(210,265,210,25);
        panel3.add(tPhone);
        tPhone.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
        
        
        tMobile = new JTextField();
        tMobile.setBounds(210,305,210,25);
        panel3.add(tMobile);
        tMobile.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
        
        tEmail = new JTextField();
        tEmail.setBounds(210,345,210,25);
        panel3.add(tEmail);
        
        //panel 4
        JPanel panel4 = new JPanel();
        panel4.setLayout(null);
        panel4.setBounds(460,340,440,350);
        panel4.setBorder(BorderFactory.createLineBorder(Color.black, 1));
        f.add(panel4 );
        
        JLabel lTitle4, lIncome, lCompanyName, lCompanyAdd, lTele, lTenure, lPosition, lMonthlyIncome;
        lTitle4 = new JLabel("Borrower's Employment Information");
        lTitle4.setBounds(20,10,200,30);
        panel4.add(lTitle4);
        
        lIncome = new JLabel("Souce of Income");
        lIncome.setBounds(20,60,150,30);
        panel4.add(lIncome);
        
        lCompanyName = new JLabel("Company / Business Name");
        lCompanyName.setBounds(20,100,200,30);
        panel4.add(lCompanyName);
        
        lCompanyAdd = new JLabel("Company / Business Address");
        lCompanyAdd.setBounds(20,140,200,30);
        panel4.add(lCompanyAdd);
        
        lTele = new JLabel("Telephone");
        lTele.setBounds(20,180,150,30);
        panel4.add(lTele);

        
        lTenure = new JLabel("Tenure in Company / Business");
        lTenure.setBounds(20,220,200,30);
        panel4.add(lTenure);
        
        lPosition = new JLabel("Position");
        lPosition.setBounds(20,260,150,30);
        panel4.add(lPosition);
        
        lMonthlyIncome = new JLabel("Monthly Income(in Php)");
        lMonthlyIncome.setBounds(20,300,150,30);
        panel4.add(lMonthlyIncome);
        
        //array for comboboxed
        String[] arrIncome = {"Please Select", "Employment", "Business", "Remittance"};
        String[] arrTenure = {"Please Select", "Less than 6 months", "6 months to less than 2 years", "2 to 5 years", "5 years or more"};
        //Comboxes
        comboIncome = new JComboBox(arrIncome);
        comboIncome.setBounds(210,65,210,25);
        panel4.add(comboIncome);
        
        comboTenure = new JComboBox(arrTenure);
        comboTenure.setBounds(210,225,210,25);
        panel4.add(comboTenure);
        
        //Textfield
        tCompanyName = new JTextField();
        tCompanyName.setBounds(210,105,210,25);
        panel4.add(tCompanyName);
        
        tCompanyAdd = new JTextField();
        tCompanyAdd.setBounds(210,145,210,25);
        panel4.add(tCompanyAdd);
        
        tTele = new JTextField();
        tTele.setBounds(210,185,210,25);
        panel4.add(tTele);
        tTele.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
        
        tPosition = new JTextField();
        tPosition.setBounds(210,265,210,25);
        panel4.add(tPosition);
        
        tMonthlyIncome = new JTextField();
        tMonthlyIncome.setBounds(210,305,210,25);
        panel4.add(tMonthlyIncome);
        tMonthlyIncome.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                if ( ((c < '0') || (c > '9')) && (c != KeyEvent.VK_BACK_SPACE)) {
                    e.consume();  // if it's not a number, ignore the event
                }
            }
        });
        
        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                
                if (firstText.getText().equals("") || middleText.getText().equals("") || lastText.getText().equals("") || comboCivil.getSelectedItem().equals("Please Select") || tAge.getText().equals("") || 
                comboType.getSelectedItem().equals("Please Select") || comboVehicleBrand.getSelectedItem().equals("Please Select") || comboDown.getSelectedItem().equals("Please Select") || comboTerm.getSelectedItem().equals("Please Select") || tPrice.getText().equals("") || tVehicleModel.getText().equals("") ||
                tStreet.getText().equals("") || tBarangay.getText().equals("") || tProvince.getText().equals("") || tPhone.getText().equals("") || tMobile.getText().equals("") || tEmail.getText().equals("") || comboStay.getSelectedItem().equals("Please Select")|| comboResidence.getSelectedItem().equals("Please Select")||
                tCompanyName.getText().equals("") || tCompanyAdd.getText().equals("") || tTele.getText().equals("") || tPosition.getText().equals("") || tMonthlyIncome.getText().equals("") || comboIncome.getSelectedItem().equals("Please Select")|| comboTenure.getSelectedItem().equals("Please Select")
                ){
                    JOptionPane.showMessageDialog(f,"Fill up the empty text field");
                    if (firstText.getText().equals("")){
                        firstText.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (middleText.getText().equals("")){
                        middleText.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (lastText.getText().equals("")){
                        lastText.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tAge.getText().equals("")){
                        tAge.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboCivil.getSelectedItem().equals("Please Select")){
                        comboCivil.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    
                    if (comboType.getSelectedItem().equals("Please Select")){
                        comboType.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboVehicleBrand.getSelectedItem().equals("Please Select")){
                        comboVehicleBrand.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboDown.getSelectedItem().equals("Please Select")){
                        comboDown.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboTerm.getSelectedItem().equals("Please Select")){
                        comboTerm.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tPrice.getText().equals("")){
                        tPrice.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tVehicleModel.getText().equals("")){
                        tVehicleModel.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    
    
                    if (tStreet.getText().equals("")){
                        tStreet.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tBarangay.getText().equals("")){
                        tBarangay.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tProvince.getText().equals("")){
                        tProvince.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tPhone.getText().equals("")){
                        tPhone.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tMobile.getText().equals("")){
                        tMobile.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tEmail.getText().equals("")){
                        tEmail.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboStay.getSelectedItem().equals("Please Select")){
                        comboStay.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboResidence.getSelectedItem().equals("Please Select")){
                        comboResidence.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    
                    if (tCompanyName.getText().equals("")){
                        tCompanyName.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tCompanyAdd.getText().equals("")){
                        tCompanyAdd.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tTele.getText().equals("")){
                        tTele.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tPosition.getText().equals("")){
                        tPosition.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (tMonthlyIncome.getText().equals("")){
                        tMonthlyIncome.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboIncome.getSelectedItem().equals("Please Select")){
                        comboIncome.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (comboTenure.getSelectedItem().equals("Please Select")){
                        comboTenure.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    
                }
                else{
                    String displayName = lastText.getText(); 
                    String[] options = {"Yes",
                    "No, back to home"};
                    int result = JOptionPane.showOptionDialog(f,
                        "Thank you for applying Mr/Ms. "+ displayName +", details will be sent to your email after screening \n and a message will be sent via sms notifying that it has been sent to your email.\n Do you want to apply again? ",
                        "Application Form",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.INFORMATION_MESSAGE,
                        null,     //do not use a custom Icon
                        options,  //the titles of buttons
                        options[0]); //default button title
                    if(result == JOptionPane.YES_OPTION){
                        applyFrame();
                        f.setVisible(false);
                    }
                    if (result == JOptionPane.NO_OPTION){
                        homePage();
                        f.setVisible(false);
                    }
                }
            }
        });             
    }
}
class loanAssessment extends CarLoanAssessment{
    //frame for auto loan
    public void autoLoanAssessment(){
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(470,525);
        
        //menu bar
        JMenu menu;
        JMenuItem home; 
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("≡");
        home=new JMenuItem("back to Home"); 
        menu.setFont(new Font("Serif", Font.BOLD, 20));
        
        menuBar.add(menu); 
        f.setJMenuBar(menuBar);
        
        menu.add(home);
        //menu bar action
        home.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                homePage();
                f.setVisible(false);
            }
        });
    
        
        JLabel lTitle,belowTitle, q1, q2,q3, q4, q5, q6, belowQuestion;
        lTitle = new JLabel("Auto Loan Self-Assessment");
        lTitle.setBounds(20,10,250,30);
        f.add(lTitle);
        
        belowTitle = new JLabel("Know if you're ready for an Auto Loan by answering the questions below:");
        belowTitle.setBounds(20,50,450,30);
        f.add(belowTitle);
        
        q1 = new JLabel("1. I am a");
        q1.setBounds(20,80,150,30);
        f.add(q1);
        
        q2 = new JLabel("2. My age is");
        q2.setBounds(20,135,450,30);
        f.add(q2);
        
        q3 = new JLabel("3. My loan purpose is");
        q3.setBounds(20,190,450,30);
        f.add(q3);
        
        q4 = new JLabel("4. I derive my income primarily from");
        q4.setBounds(20,245,450,30);
        f.add(q4);
        
        q5 = new JLabel("5. My monthly income is");
        q5.setBounds(20,300,450,30);
        f.add(q5);
        
        q6 = new JLabel("6. My intended loan amount is");
        q6.setBounds(20,355,450,30);
        f.add(q6);
        
        
        String[] firstlist = {"Please Select", "Filipino","Foreign resident with stable Filipino co-maker","Foreign National"};
        String[] secondlist = {"Please Select", "Below 21 years old"," 21 years old above"};
        String[] thirdlist = {"Please Select", "Brand New Car","2nd Hand Unit not more than 5 years old","2nd Hand Unit more than 6 years old"};
        String[] forthlist = {"Please Select", "Full time employment","Commissions","Own business"};
        String[] fifthlist = {"Please Select", "Below Php 40,000","Between Php 40,000 - Php 200,000","Above Php 200,000"};
        String[] sixlist = {"Please Select", "Below Php 200,000","From Php 200,000 - Php 500,000","Above Php 500,000"};
        JComboBox firstQ, secondQ, thirdQ, forthQ, fifthQ, sixQ;
        
        firstQ = new JComboBox(firstlist);
        firstQ.setBounds(20,110,400,25);
        f.add(firstQ);
        
        secondQ = new JComboBox(secondlist);
        secondQ.setBounds(20,165,400,25);
        f.add(secondQ);
        
        thirdQ = new JComboBox(thirdlist);
        thirdQ.setBounds(20,220,400,25);
        f.add(thirdQ);
        
        forthQ = new JComboBox(forthlist);
        forthQ.setBounds(20,275,400,25);
        f.add(forthQ);
        
        fifthQ = new JComboBox(fifthlist);
        fifthQ.setBounds(20,330,400,25);
        f.add(fifthQ);
        
        sixQ = new JComboBox(sixlist);
        sixQ.setBounds(20,385,400,25);
        f.add(sixQ);
        
        JButton ok = new JButton("Assess");
        ok.setBounds(180,420,90,30); 
        f.add(ok);
        ok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                if (firstQ.getSelectedItem().equals("Please Select")||secondQ.getSelectedItem().equals("Please Select")||thirdQ.getSelectedItem().equals("Please Select")||forthQ.getSelectedItem().equals("Please Select")||fifthQ.getSelectedItem().equals("Please Select")||sixQ.getSelectedItem().equals("Please Select")){
                    JOptionPane.showMessageDialog(f,"Fill up the empty text field");
                    if (firstQ.getSelectedItem().equals("Please Select")){
                        firstQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (secondQ.getSelectedItem().equals("Please Select")){
                        secondQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (thirdQ.getSelectedItem().equals("Please Select")){
                        thirdQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (forthQ.getSelectedItem().equals("Please Select")){
                        forthQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (fifthQ.getSelectedItem().equals("Please Select")){
                        fifthQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                    if (sixQ.getSelectedItem().equals("Please Select")){
                        sixQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                    }
                }
                if (firstQ.getSelectedItem().equals("Foreign National")){
                    JOptionPane.showMessageDialog(f,"You need a stable Filipino co-maker to apply for a BPI Auto Loan.");
                    firstQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (secondQ.getSelectedItem().equals("Below 21 years old")){
                    JOptionPane.showMessageDialog(f,"You should be at least 21 years of age to be able to qualify.");
                    secondQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (thirdQ.getSelectedItem().equals("2nd Hand Unit more than 6 years old")){
                    JOptionPane.showMessageDialog(f,"Only brand new cars and 2nd hand units not more than 5 years old are acceptable for the loan.");
                    thirdQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (forthQ.getSelectedItem().equals("Commissions")){
                    JOptionPane.showMessageDialog(f,"To qualify for a loan, income should be derived from full time employment or own business.");
                    forthQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (fifthQ.getSelectedItem().equals("Below Php 40,000")){
                    JOptionPane.showMessageDialog(f,"To qualify for a loan, the minimum monthly household income should be Php 40,000.");
                    fifthQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                if (sixQ.getSelectedItem().equals("Below Php 200,000")){
                    JOptionPane.showMessageDialog(f,"The minimum loan amount for a BPI Auto Loan is Php 200,000.");
                    sixQ.setBorder(BorderFactory.createLineBorder(Color.red, 1));
                }
                
                if (!firstQ.getSelectedItem().equals("Foreign National")&& !firstQ.getSelectedItem().equals("Please Select")){
                    firstQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!secondQ.getSelectedItem().equals("Below 21 years old")&& !secondQ.getSelectedItem().equals("Please Select")){
                    secondQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!thirdQ.getSelectedItem().equals("2nd Hand Unit more than 6 years old")&& !thirdQ.getSelectedItem().equals("Please Select")){
                    thirdQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!forthQ.getSelectedItem().equals("Commissions") && !forthQ.getSelectedItem().equals("Please Select")){
                    forthQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!fifthQ.getSelectedItem().equals("Below Php 40,000")&& !fifthQ.getSelectedItem().equals("Please Select")){
                    fifthQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!sixQ.getSelectedItem().equals("Below Php 200,000") && !sixQ.getSelectedItem().equals("Please Select")){
                    sixQ.setBorder(BorderFactory.createLineBorder(Color.white));
                }
                if (!firstQ.getSelectedItem().equals("Foreign National")&& !firstQ.getSelectedItem().equals("Please Select")&&
                !secondQ.getSelectedItem().equals("Below 21 years old")&& !secondQ.getSelectedItem().equals("Please Select")&&
                !thirdQ.getSelectedItem().equals("2nd Hand Unit more than 6 years old")&& !thirdQ.getSelectedItem().equals("Please Select")&&
                !fifthQ.getSelectedItem().equals("Below Php 40,000")&& !fifthQ.getSelectedItem().equals("Please Select")&&
                !fifthQ.getSelectedItem().equals("Below Php 40,000")&& !fifthQ.getSelectedItem().equals("Please Select")&&
                !sixQ.getSelectedItem().equals("Below Php 200,000") && !sixQ.getSelectedItem().equals("Please Select")){
                    JOptionPane.showMessageDialog(f,"Congratulations! You are ready to apply for a KK&JC Auto Loan.\nApply now so that you can drive your dream car soon.");
                    firstQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    secondQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    thirdQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    forthQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    fifthQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    sixQ.setBorder(BorderFactory.createLineBorder(Color.white));
                    String[] options = {"Yes",
                    "No, back to home"};
                    int result = JOptionPane.showOptionDialog(f,
                        "Congratulations! You are ready to apply for a KK&JC Auto Loan.\nApply now so that you can drive your dream car soon.\n Do you want assess again?",
                        "Auto Loan Assessment",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.QUESTION_MESSAGE,
                        null,     //do not use a custom Icon
                        options,  //the titles of buttons
                        options[0]); //default button title
                    if(result == JOptionPane.YES_OPTION){
                        autoLoanAssessment();
                        f.setVisible(false);
                    }
                    if (result == JOptionPane.NO_OPTION){
                        homePage();
                        f.setVisible(false);
                    }
                }
            }
        });
    }
}

class about extends CarLoanAssessment{
    public void aboutUsFrame(){
    
        f.setLayout(null);
        f.setVisible(true);
        f.setSize(450,430);
        //menuuuuuuuuuu
        //menu bar
        JMenu menu;
        JMenuItem home; 
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("≡");
        home=new JMenuItem("back to Home"); 
        menu.setFont(new Font("Serif", Font.BOLD, 20));
        
        menuBar.add(menu); 
        f.setJMenuBar(menuBar);
        
        menu.add(home);
        //menu bar action
        home.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e){
                homePage();
                f.setVisible(false);
            }
        });
        
        
        
        //label
        JLabel ComapanyName, lAboutUs, body, roles, JC, karl, kenneth, jcBody, karlBody, kennethBody ;
        
        ComapanyName = new JLabel("K K & J C");
        ComapanyName.setBounds(15,5,250,50);    
        ComapanyName.setFont(new Font("Serif", Font.PLAIN, 35));
        f.add(ComapanyName);
        
        lAboutUs = new JLabel("-- About Us --");
        lAboutUs.setBounds(15,85,190,30);
        lAboutUs.setFont(new Font("Serif", Font.PLAIN, 20));
        f.add(lAboutUs);
        
        body = new JLabel("KK&JC is a financial services company that provides credit to deserving");
        body.setBounds(15,80,420,100);
        f.add(body);
        
        body = new JLabel("individuals for a car. We simplify how you get access to loans.");
        body.setBounds(15,100,350,100);
        f.add(body);

        roles = new JLabel("-- Roles --");
        roles.setBounds(15,180,190,30);
        roles.setFont(new Font("Serif", Font.PLAIN, 20));
        f.add(roles);
    
        JC = new JLabel("John Clarenz Garcia");

        JC.setBounds(15,170,350,100);
        f.add(JC);
        
        karl = new JLabel("Karl Ian Suba");
        karl.setBounds(15,220,350,100);
        f.add(karl);
        
        kenneth = new JLabel("Kenneth Angelo Iino");
        kenneth.setBounds(15,270,350,100);
        f.add(kenneth);
        
        jcBody = new JLabel("- UML diagram");
        jcBody.setBounds(20,190,350,100);
        f.add(jcBody);
        
        karlBody = new JLabel("- Programmer");
        karlBody.setBounds(20,240,350,100);
        f.add(karlBody);
        
        kennethBody = new JLabel("- Flowchart");
        kennethBody.setBounds(20,290,350,100);
        f.add(kennethBody);
    }
}
